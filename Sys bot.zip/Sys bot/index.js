require("dotenv").config();
const fs = require("fs");
const path = require("path");
const {
  Client,
  GatewayIntentBits,
  Events,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");

// ===== ENV =====
const {
  TOKEN,
  GUILD_ID,
  OWNER_IDS,
  TICKET_CATEGORY_ID,
  STAFF_ROLE_ID,
  LOG_CHANNEL_ID,
  BTC_ADDRESS,
  ETH_ADDRESS,
  LTC_ADDRESS,
  SOL_ADDRESS,
  THUMBNAIL_URL,
  BANNER_URL,
} = process.env;

if (!TOKEN || !GUILD_ID || !OWNER_IDS || !TICKET_CATEGORY_ID || !STAFF_ROLE_ID) {
  console.error("Missing .env values. Required: TOKEN, GUILD_ID, OWNER_IDS, TICKET_CATEGORY_ID, STAFF_ROLE_ID");
  process.exit(1);
}

const OWNERS = OWNER_IDS.split(",").map((x) => x.trim()).filter(Boolean);
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// ===== STYLE =====
const COLOR = 0x2b2d31;
const QUANTITIES = [1, 2, 3, 5, 10];

// ===== PRODUCTS STORAGE =====
const PRODUCTS_PATH = path.join(__dirname, "products.json");

function loadProducts() {
  try {
    if (!fs.existsSync(PRODUCTS_PATH)) return [];
    const raw = fs.readFileSync(PRODUCTS_PATH, "utf8");
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function saveProducts(products) {
  fs.writeFileSync(PRODUCTS_PATH, JSON.stringify(products, null, 2), "utf8");
}

function getProducts() {
  return loadProducts().filter((p) => p && p.sku && p.name && Number.isFinite(p.priceEUR));
}

// ===== TICKET STATE (memory) =====
/**
 * ticketState[channelId] = {
 *   openerId, type,
 *   claimedBy,
 *   language,
 *   step,
 *   headerMsgId,
 *   wizardMsgId,
 *   selectedProductSku,
 *   cart: [{sku,name,priceEUR,qty}],
 *   crypto: {coin,address} | null
 * }
 */
const ticketState = new Map();

function isOwner(userId) {
  return OWNERS.includes(userId);
}
function isStaff(member) {
  return member?.roles?.cache?.has?.(STAFF_ROLE_ID);
}
function euro(n) {
  return `${n.toFixed(2)}€`;
}
function total(cart) {
  return cart.reduce((s, it) => s + it.priceEUR * it.qty, 0);
}
function cleanName(s) {
  return (s || "")
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}
function baseEmbed() {
  const e = new EmbedBuilder().setColor(COLOR);
  if (THUMBNAIL_URL) e.setThumbnail(THUMBNAIL_URL);
  if (BANNER_URL) e.setImage(BANNER_URL);
  return e;
}
async function logToStaff(guild, embed) {
  if (!LOG_CHANNEL_ID) return;
  const ch = guild.channels.cache.get(LOG_CHANNEL_ID);
  if (ch && ch.isTextBased()) await ch.send({ embeds: [embed] });
}

// ===== HEADER =====
function headerEmbed(t) {
  const opener = `<@${t.openerId}>`;
  const claimed = t.claimedBy ? `<@${t.claimedBy}>` : "Unclaimed";

  return baseEmbed()
    .setTitle(`${t.type} Ticket`)
    .setDescription(
      `**User:** ${opener}\n` +
      `**Category:** ${t.type}\n` +
      `**Language:** ${t.language || "Not selected"}\n` +
      `**Claimed:** ${claimed}`
    );
}
function headerRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("t_close").setLabel("Close").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("t_claim").setLabel("Claim").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("t_unclaim").setLabel("Unclaim").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("t_notify").setLabel("Notify").setStyle(ButtonStyle.Secondary)
  );
}

// ===== WIZARD =====
function wizardEmbed(t) {
  const e = baseEmbed();

  if (t.step === "TOS") {
    return e
      .setTitle("Terms of Service")
      .setDescription(
        "Please read and accept the Terms of Service to proceed.\n\n" +
        "**By accepting, you agree to the terms of our service.**\n" +
        "If you click decline, the channel will be deleted."
      );
  }

  if (t.step === "LANG") {
    return e.setTitle("Select Language").setDescription("Please select your preferred language.");
  }

  // Non-buy tickets end here
  if (t.type !== "Buy" && t.step === "DESCRIBE") {
    return e
      .setTitle("Request Details")
      .setDescription("Please describe your request in this channel. A staff member will respond.");
  }

  // Buy flow
  if (t.step === "PRODUCT") {
    return e.setTitle("Select Product").setDescription("Please select the product you want to buy.");
  }

  if (t.step === "QTY") {
    const products = getProducts();
    const p = products.find((x) => x.sku === t.selectedProductSku);
    return e
      .setTitle("Select Quantity")
      .addFields({ name: "Product", value: p ? `\`${p.name}\`` : "`Not selected`" })
      .setDescription("Please select the quantity.");
  }

  if (t.step === "CART") {
    const lines = t.cart.length
      ? t.cart
          .map((it, i) => `${i + 1}. **${it.qty}x** \`${it.name}\` - **${euro(it.qty * it.priceEUR)}**`)
          .join("\n")
      : "_Cart is empty._";

    return e
      .setTitle("Shopping Cart")
      .setDescription("Please review your cart before checking out.")
      .addFields(
        { name: "Items", value: lines },
        { name: "Total Amount", value: `**${euro(total(t.cart))}**` }
      );
  }

  if (t.step === "CHECKOUT") {
    return e
      .setTitle("Secure Checkout")
      .addFields(
        { name: "Total Amount", value: `**${euro(total(t.cart))}**` },
        { name: "Payment Method", value: "**Crypto only**" },
        { name: "Security", value: "Secure Payment Process" }
      )
      .setDescription("Choose your preferred cryptocurrency.");
  }

  // CRYPTO_ADDR
  return e
    .setTitle("Secure Checkout")
    .addFields(
      { name: "Total Amount", value: `**${euro(total(t.cart))}**` },
      { name: "Payment Method", value: `Crypto (${t.crypto?.coin || "N/A"})` },
      { name: "Security", value: "Secure Payment Process" },
      { name: "Crypto Address", value: `\`${t.crypto?.address || "N/A"}\`` }
    )
    .setDescription("After sending, click **Confirm Payment** and submit your explorer link.");
}

function wizardComponents(t) {
  if (t.step === "TOS") {
    return [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("tos_accept").setLabel("Accept").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("tos_decline").setLabel("Decline").setStyle(ButtonStyle.Danger)
      ),
    ];
  }

  if (t.step === "LANG") {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("lang_select")
      .setPlaceholder("Select language...")
      .addOptions([{ label: "English", value: "English", emoji: "🇬🇧" }]);
    return [new ActionRowBuilder().addComponents(menu)];
  }

  if (t.type !== "Buy" && t.step === "DESCRIBE") {
    // no components needed
    return [];
  }

  // Buy components
  if (t.step === "PRODUCT") {
    const products = getProducts();
    if (!products.length) {
      // If no products exist, no menu. (You add with /product add)
      const dummy = new StringSelectMenuBuilder()
        .setCustomId("product_select")
        .setPlaceholder("No products configured")
        .setDisabled(true)
        .addOptions([{ label: "Add products with /product add", value: "none" }]);
      return [new ActionRowBuilder().addComponents(dummy)];
    }

    const menu = new StringSelectMenuBuilder()
      .setCustomId("product_select")
      .setPlaceholder("Select product...")
      .addOptions(
        products.slice(0, 25).map((p) => ({
          label: p.name,
          value: p.sku,
          description: `Price: ${euro(p.priceEUR)}`,
        }))
      );
    return [new ActionRowBuilder().addComponents(menu)];
  }

  if (t.step === "QTY") {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("qty_select")
      .setPlaceholder("Select quantity...")
      .addOptions(QUANTITIES.map((q) => ({ label: `${q}`, value: `${q}` })));
    return [new ActionRowBuilder().addComponents(menu)];
  }

  if (t.step === "CART") {
    return [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("cart_add").setLabel("Add Product").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("cart_checkout").setLabel("Checkout").setStyle(ButtonStyle.Success)
      ),
    ];
  }

  if (t.step === "CHECKOUT") {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("crypto_select")
      .setPlaceholder("Select crypto type...")
      .addOptions(
        { label: "Bitcoin (BTC)", value: "BTC" },
        { label: "Ethereum (ETH)", value: "ETH" },
        { label: "Litecoin (LTC)", value: "LTC" },
        { label: "Solana (SOL)", value: "SOL" }
      );
    return [new ActionRowBuilder().addComponents(menu)];
  }

  // CRYPTO_ADDR
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("crypto_confirm_modal").setLabel("Confirm Payment").setStyle(ButtonStyle.Success)
    ),
  ];
}

async function updateHeader(channel, t) {
  const msg = await channel.messages.fetch(t.headerMsgId);
  await msg.edit({ embeds: [headerEmbed(t)], components: [headerRow()] });
}
async function updateWizard(channel, t) {
  const msg = await channel.messages.fetch(t.wizardMsgId);
  await msg.edit({ embeds: [wizardEmbed(t)], components: wizardComponents(t) });
}

// ===== COMMAND REGISTRATION =====
client.once(Events.ClientReady, async () => {
  console.log(`Logged in as ${client.user.tag}`);

  const guild = await client.guilds.fetch(GUILD_ID);

  await guild.commands.set([
    {
      name: "ticketmenu",
      description: "Post the ticket menu (owners only)",
    },
    {
      name: "product",
      description: "Manage products (owners only)",
      options: [
        {
          type: 1, // SUB_COMMAND
          name: "add",
          description: "Add a new product",
          options: [
            { type: 3, name: "sku", description: "Unique id (e.g. vpn-tunnelbear)", required: true },
            { type: 3, name: "name", description: "Display name", required: true },
            { type: 10, name: "price", description: "Price in EUR (e.g. 2.99)", required: true },
          ],
        },
        {
          type: 1,
          name: "edit",
          description: "Edit an existing product",
          options: [
            { type: 3, name: "sku", description: "SKU to edit", required: true },
            { type: 3, name: "name", description: "New name (optional)", required: false },
            { type: 10, name: "price", description: "New price in EUR (optional)", required: false },
          ],
        },
        {
          type: 1,
          name: "remove",
          description: "Remove a product",
          options: [{ type: 3, name: "sku", description: "SKU to remove", required: true }],
        },
        {
          type: 1,
          name: "list",
          description: "List products",
        },
      ],
    },
  ]);

  console.log("Registered /ticketmenu and /product");
});

// ===== INTERACTIONS =====
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    // ========== /product ==========
    if (interaction.isChatInputCommand() && interaction.commandName === "product") {
      if (!isOwner(interaction.user.id)) {
        return interaction.reply({ content: "No permission.", ephemeral: true });
      }

      const sub = interaction.options.getSubcommand();
      const products = getProducts();

      if (sub === "add") {
        const sku = interaction.options.getString("sku", true).trim();
        const name = interaction.options.getString("name", true).trim();
        const price = interaction.options.getNumber("price", true);

        if (!Number.isFinite(price) || price <= 0) {
          return interaction.reply({ content: "Price must be a positive number.", ephemeral: true });
        }
        if (products.some((p) => p.sku === sku)) {
          return interaction.reply({ content: "That SKU already exists.", ephemeral: true });
        }

        const newProducts = [...products, { sku, name, priceEUR: price }];
        saveProducts(newProducts);

        return interaction.reply({
          content: `✅ Added: \`${sku}\` — **${name}** — **${euro(price)}**`,
          ephemeral: true,
        });
      }

      if (sub === "edit") {
        const sku = interaction.options.getString("sku", true).trim();
        const name = interaction.options.getString("name", false);
        const price = interaction.options.getNumber("price", false);

        const idx = products.findIndex((p) => p.sku === sku);
        if (idx === -1) return interaction.reply({ content: "SKU not found.", ephemeral: true });

        const updated = [...products];
        if (typeof name === "string" && name.trim().length) updated[idx].name = name.trim();
        if (typeof price === "number") {
          if (!Number.isFinite(price) || price <= 0) {
            return interaction.reply({ content: "Price must be a positive number.", ephemeral: true });
          }
          updated[idx].priceEUR = price;
        }
        saveProducts(updated);

        return interaction.reply({
          content: `✅ Updated: \`${sku}\` — **${updated[idx].name}** — **${euro(updated[idx].priceEUR)}**`,
          ephemeral: true,
        });
      }

      if (sub === "remove") {
        const sku = interaction.options.getString("sku", true).trim();
        if (!products.some((p) => p.sku === sku)) {
          return interaction.reply({ content: "SKU not found.", ephemeral: true });
        }
        const updated = products.filter((p) => p.sku !== sku);
        saveProducts(updated);

        return interaction.reply({ content: `✅ Removed: \`${sku}\``, ephemeral: true });
      }

      if (sub === "list") {
        if (!products.length) {
          return interaction.reply({ content: "No products. Add with `/product add`.", ephemeral: true });
        }
        const lines = products
          .slice(0, 50)
          .map((p) => `• \`${p.sku}\` — **${p.name}** — **${euro(p.priceEUR)}**`)
          .join("\n");

        return interaction.reply({ content: lines, ephemeral: true });
      }
    }

    // ========== /ticketmenu ==========
    if (interaction.isChatInputCommand() && interaction.commandName === "ticketmenu") {
      if (!isOwner(interaction.user.id)) {
        return interaction.reply({ content: "No permission.", ephemeral: true });
      }

      const embed = baseEmbed()
        .setTitle("Ticket System")
        .setDescription("Select the type of ticket you want to open.");

      const menu = new StringSelectMenuBuilder()
        .setCustomId("ticket_type")
        .setPlaceholder("Select a ticket type...")
        .addOptions(
          { label: "Buy", value: "Buy", emoji: "🛒", description: "Purchase products" },
          { label: "Verify", value: "Verify", emoji: "✅", description: "Verification request" },
          { label: "Question", value: "Question", emoji: "❓", description: "Ask a question" }
        );

      return interaction.reply({
        embeds: [embed],
        components: [new ActionRowBuilder().addComponents(menu)],
      });
    }

    // ========== Create ticket channel ==========
    if (interaction.isStringSelectMenu() && interaction.customId === "ticket_type") {
      await interaction.deferReply({ ephemeral: true });

      const guild = interaction.guild;
      const category = guild.channels.cache.get(TICKET_CATEGORY_ID);
      if (!category || category.type !== ChannelType.GuildCategory) {
        return interaction.editReply("Ticket category ID is invalid (must be a Category).");
      }

      const staffRole = guild.roles.cache.get(STAFF_ROLE_ID);
      if (!staffRole) return interaction.editReply("Staff role not found.");

      const existing = guild.channels.cache.find(
        (ch) => ch.type === ChannelType.GuildText && ch.topic === `ticket:${interaction.user.id}`
      );
      if (existing) return interaction.editReply(`You already have an open ticket: ${existing}`);

      const type = interaction.values[0]; // Buy / Verify / Question
      const channelName = `${cleanName(interaction.user.username)}-${cleanName(type)}-ticket`.slice(0, 90);

      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: category.id,
        topic: `ticket:${interaction.user.id}`,
        permissionOverwrites: [
          { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          },
          {
            id: staffRole.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageMessages,
            ],
          },
        ],
      });

      const t = {
        openerId: interaction.user.id,
        type,
        claimedBy: null,
        language: "Not selected",
        step: "TOS",
        headerMsgId: null,
        wizardMsgId: null,
        selectedProductSku: null,
        cart: [],
        crypto: null,
      };
      ticketState.set(channel.id, t);

      const headerMsg = await channel.send({ embeds: [headerEmbed(t)], components: [headerRow()] });
      const wizardMsg = await channel.send({ embeds: [wizardEmbed(t)], components: wizardComponents(t) });

      t.headerMsgId = headerMsg.id;
      t.wizardMsgId = wizardMsg.id;

      return interaction.editReply(`Ticket created: ${channel}`);
    }

    // ========== Confirm Payment (Modal) ==========
    if (interaction.isButton() && interaction.customId === "crypto_confirm_modal") {
      const t = ticketState.get(interaction.channelId);
      if (!t) return;
      if (interaction.user.id !== t.openerId) return;
      if (!t.crypto) return;

      const modal = new ModalBuilder()
        .setCustomId("modal_crypto_payment")
        .setTitle("Crypto Payment Confirmation");

      const input = new TextInputBuilder()
        .setCustomId("explorer_link")
        .setLabel("Explorer / Tx Link")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("Paste Solscan / Blockchair / Etherscan link...")
        .setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(input));
      return interaction.showModal(modal);
    }

    // ========== In-ticket interactions (clean: deferUpdate) ==========
    if (interaction.isButton() || interaction.isStringSelectMenu()) {
      const t = ticketState.get(interaction.channelId);
      if (!t) return;

      // Keep UI clean
      await interaction.deferUpdate();

      // ---- Header controls
      if (interaction.isButton() && ["t_close", "t_claim", "t_unclaim", "t_notify"].includes(interaction.customId)) {
        if (interaction.customId === "t_close") {
          const opener = interaction.user.id === t.openerId;
          const staff = isStaff(interaction.member);
          if (!opener && !staff && !isOwner(interaction.user.id)) return;

          setTimeout(() => {
            if (interaction.channel?.deletable) interaction.channel.delete("Ticket closed");
            ticketState.delete(interaction.channelId);
          }, 1200);
          return;
        }

        if (interaction.customId === "t_claim") {
          if (!isStaff(interaction.member) && !isOwner(interaction.user.id)) return;
          t.claimedBy = interaction.user.id;
          await updateHeader(interaction.channel, t);
          return;
        }

        if (interaction.customId === "t_unclaim") {
          if (!isStaff(interaction.member) && !isOwner(interaction.user.id)) return;
          t.claimedBy = null;
          await updateHeader(interaction.channel, t);
          return;
        }

        if (interaction.customId === "t_notify") {
          if (!isStaff(interaction.member) && !isOwner(interaction.user.id)) return;
          // No channel spam
          interaction.user.send?.("Please check your ticket.").catch(() => {});
          return;
        }
      }

      // ---- Wizard opener-only actions
      const openerOnly =
        ["tos_accept", "tos_decline", "cart_add", "cart_checkout"].includes(interaction.customId) ||
        ["lang_select", "product_select", "qty_select", "crypto_select"].includes(interaction.customId);

      if (openerOnly && interaction.user.id !== t.openerId) return;

      // ToS
      if (interaction.isButton() && interaction.customId === "tos_accept") {
        t.step = "LANG";
        await updateWizard(interaction.channel, t);
        await updateHeader(interaction.channel, t);
        return;
      }
      if (interaction.isButton() && interaction.customId === "tos_decline") {
        setTimeout(() => {
          if (interaction.channel?.deletable) interaction.channel.delete("ToS declined");
          ticketState.delete(interaction.channelId);
        }, 1200);
        return;
      }

      // Language
      if (interaction.isStringSelectMenu() && interaction.customId === "lang_select") {
        t.language = interaction.values[0]; // English
        // If Buy => product flow; else => describe
        t.step = t.type === "Buy" ? "PRODUCT" : "DESCRIBE";
        await updateHeader(interaction.channel, t);
        await updateWizard(interaction.channel, t);
        return;
      }

      // Non-buy tickets stop here
      if (t.type !== "Buy") return;

      // Cart buttons
      if (interaction.isButton() && interaction.customId === "cart_add") {
        t.step = "PRODUCT";
        await updateWizard(interaction.channel, t);
        return;
      }
      if (interaction.isButton() && interaction.customId === "cart_checkout") {
        if (!t.cart.length) return;
        t.step = "CHECKOUT";
        await updateWizard(interaction.channel, t);
        return;
      }

      // Product select
      if (interaction.isStringSelectMenu() && interaction.customId === "product_select") {
        const sku = interaction.values[0];
        const products = getProducts();
        const p = products.find((x) => x.sku === sku);
        if (!p) return;

        t.selectedProductSku = sku;
        t.step = "QTY";
        await updateWizard(interaction.channel, t);
        return;
      }

      // Qty select -> add to cart
      if (interaction.isStringSelectMenu() && interaction.customId === "qty_select") {
        const qty = Number(interaction.values[0]);
        const products = getProducts();
        const p = products.find((x) => x.sku === t.selectedProductSku);
        if (!p || !Number.isFinite(qty) || qty <= 0) return;

        const ex = t.cart.find((it) => it.sku === p.sku);
        if (ex) ex.qty += qty;
        else t.cart.push({ sku: p.sku, name: p.name, priceEUR: p.priceEUR, qty });

        t.selectedProductSku = null;
        t.step = "CART";
        await updateWizard(interaction.channel, t);
        return;
      }

      // Crypto select
      if (interaction.isStringSelectMenu() && interaction.customId === "crypto_select") {
        const coin = interaction.values[0];
        let address = null;
        if (coin === "BTC") address = BTC_ADDRESS || null;
        if (coin === "ETH") address = ETH_ADDRESS || null;
        if (coin === "LTC") address = LTC_ADDRESS || null;
        if (coin === "SOL") address = SOL_ADDRESS || null;
        if (!address) return;

        t.crypto = { coin, address };
        t.step = "CRYPTO_ADDR";
        await updateWizard(interaction.channel, t);
        return;
      }
    }

    // ========== Modal submit ==========
    if (interaction.isModalSubmit() && interaction.customId === "modal_crypto_payment") {
      const t = ticketState.get(interaction.channelId);
      if (!t) return interaction.reply({ content: "Not a ticket channel.", ephemeral: true });
      if (interaction.user.id !== t.openerId) return interaction.reply({ content: "Opener only.", ephemeral: true });

      const link = interaction.fields.getTextInputValue("explorer_link")?.trim();

      await interaction.reply({ content: "✅ Payment submitted for staff review.", ephemeral: true });

      const items = t.cart.map((it) => `${it.qty}x ${it.name}`).join(", ") || "None";

      const embed = new EmbedBuilder()
        .setTitle("Payment Submitted")
        .setColor(0x57f287)
        .addFields(
          { name: "Ticket", value: `<#${interaction.channelId}>` },
          { name: "User", value: `<@${t.openerId}>` },
          { name: "Items", value: `\`${items}\`` },
          { name: "Total", value: `**${euro(total(t.cart))}**` },
          { name: "Coin", value: `**${t.crypto?.coin || "N/A"}**`, inline: true },
          { name: "Address", value: `\`${t.crypto?.address || "N/A"}\`` },
          { name: "Explorer Link", value: link || "N/A" }
        );

      await logToStaff(interaction.guild, embed);
      return;
    }
  } catch (err) {
    console.error("Interaction error:", err);
    try {
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: "Error. Check console.", ephemeral: true });
      }
    } catch {}
  }
});

client.login(TOKEN);